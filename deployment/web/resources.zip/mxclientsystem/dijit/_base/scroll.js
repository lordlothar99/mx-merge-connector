//>>built
define("dijit/_base/scroll",["dojo/window","../main"],function(_1,_2){
_2.scrollIntoView=function(_3,_4){
_1.scrollIntoView(_3,_4);
};
});
