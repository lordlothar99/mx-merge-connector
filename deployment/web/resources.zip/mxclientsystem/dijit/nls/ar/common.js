//>>built
define("dijit/nls/ar/common",({buttonOk:"حسنا",buttonCancel:"الغاء",buttonSave:"حفظ",itemClose:"اغلاق"}));
