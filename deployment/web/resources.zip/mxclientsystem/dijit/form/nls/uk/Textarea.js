//>>built
define("dijit/form/nls/uk/Textarea",({iframeEditTitle:"область редагування",iframeFocusTitle:"фрейм області редагування"}));
